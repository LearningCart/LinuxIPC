files barrier.c  condbcast.c  cond.c  mutex.c  rwlock.c are created by me
sharedmutex created by yamnikov-oleg
