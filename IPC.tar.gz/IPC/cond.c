#include <stdio.h>
#include <pthread.h>



static pthread_cond_t  cond = PTHREAD_COND_INITIALIZER;
static pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

static int condition = 0;
void * Producer(void *p)
{

	sleep(4);
	printf("Producer: changing the condition..., \n");
	pthread_mutex_lock(&lock);

	condition = 1;

	pthread_mutex_unlock(&lock);

	printf("Producer: signaling the condition..., \n");
	pthread_cond_signal(&cond);

	return NULL;
}

void * Consumer(void *p)
{

	printf("Consumer: waiting the condition..., \n");
	pthread_mutex_lock(&lock);

	while( condition == 0)
		pthread_cond_wait(&cond, &lock);

	printf("Consumer: condition changed..., \n");
		
	pthread_mutex_unlock(&lock);


	return NULL;
}
int main(int argc, char **argv)
{
	pthread_t prod,consu;
	int i;


	pthread_create(&(prod), NULL, Producer, NULL);
	pthread_create(&(consu), NULL, Consumer, NULL);

	pthread_join(prod, NULL);
	pthread_join(consu, NULL);
	
	printf("OK Bye...,\n");
	return 0;
}

