#include <stdio.h>
#include <pthread.h>



#ifdef WITHLOCK
static pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
#endif

static unsigned int count = 0;
void * Thread1(void *p)
{
	int loop;
	loop = (int) p;
	while(loop > 0)
	{
#ifdef WITHLOCK
		pthread_mutex_lock(&lock);
#endif

		count++;

#ifdef WITHLOCK
		pthread_mutex_unlock(&lock);
#endif
		loop--;
	}

	return NULL;
}
int main(int argc, char **argv)
{
	pthread_t prod,consu;
	int i;


	pthread_create(&(prod),   NULL, Thread1, (void *)10000000);
	pthread_create(&(consu),  NULL, Thread1, (void *)10000000);

	pthread_join(prod, NULL);
	pthread_join(consu, NULL);
	printf("Count: %u\n", count);
	
	printf("OK Bye...,\n");
	return 0;
}

