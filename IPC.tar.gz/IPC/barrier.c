#include <stdio.h>
#include <pthread.h>


#define MAX_THREADS	(5)

static pthread_barrier_t bar;

void * Threadfn(void *p)
{
	int i;
	i = (int) p;


	printf("Waiting for all to meet : %d\n",i);
	pthread_barrier_wait(&bar);
	printf("Lets go : %d\n",i);
	return NULL;
}

int main(int argc, char **argv)
{
	pthread_t thrs[MAX_THREADS];
	int i;

	pthread_barrier_init(&bar, NULL, MAX_THREADS);

	for(i = 0; i < MAX_THREADS; i++)
	{
		pthread_create(&thrs[i], NULL, Threadfn, (void *)i);
	}

	for(i = 0; i < MAX_THREADS; i++)
	{
		pthread_join(thrs[i], NULL);
	}
	
	printf("OK Bye...,\n");
	return 0;
}

