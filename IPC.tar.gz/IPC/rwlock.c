#include <stdio.h>
#include <pthread.h>


pthread_rwlock_t        rwlock1 = PTHREAD_RWLOCK_INITIALIZER;

static unsigned int count = 0;
void * Reader(void *p)
{
	printf("IN: %s() -> %d\n",__func__, (int) p);

	while(1)
	{
		pthread_rwlock_rdlock(&rwlock1);
		printf("Read lock acquired...: %s()->%d:  %u\n",__func__, (int) p, count);
		pthread_rwlock_rdlock(&rwlock1);
		sleep(1);
	}
	printf("OUT : %s()\n",__func__);
	return NULL;
}
void * Writer(void *p)
{
	printf("IN: %s()\n",__func__);
	while(1)
	{
		sleep(4);
		pthread_rwlock_rdlock(&rwlock1);
		printf("Write lock acquired...\n");
		count++;
		pthread_rwlock_rdlock(&rwlock1);
	}


	printf("OUT : %s()\n",__func__);
	return NULL;
}
int main(int argc, char **argv)
{
	pthread_t prod, prod2, prod3,consu;
	int i;


	pthread_create(&(prod),   NULL, Reader, (void *)1);
	pthread_create(&(prod2),  NULL, Reader, (void *)2);
	pthread_create(&(prod3),  NULL, Reader, (void *)3);
	pthread_create(&(consu),  NULL, Writer, NULL);

	pthread_join(prod, NULL);
	pthread_join(prod2, NULL);
	pthread_join(prod3, NULL);
	pthread_join(consu, NULL);
	printf("Count: %u\n", count);
	
	printf("OK Bye...,\n");
	return 0;
}

